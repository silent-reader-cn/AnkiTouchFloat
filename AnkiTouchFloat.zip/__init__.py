from . import main
main.init()